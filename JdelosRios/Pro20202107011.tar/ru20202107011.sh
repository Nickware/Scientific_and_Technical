echo "Descomprimir archivo .tar"
echo "Descomprimiendo archivos"
tar -xvf Pro20202107011.tar

