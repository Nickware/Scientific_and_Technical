#! /usr/bin/bash
# Title: "PArcial 2"
# Author: Marcos Torres
# Date: 07/09/2021
# Version: 0.0.1
# Ultimo digito documento : 8
# ultimo digito codigo estudiantil : 4

# rm me ayuda a remover un arhivo txt con el fin de que si quiero ejecutar el script de nuevo, no vaya a tener ningun prolema
rm me20202107044.txt
# echo me ayuda a mostrar en pantalla un mensaje que se encuentra dentro de las " "
echo "Hola, para empezar dime cual es tu nombre: "
# read me permite interactuar con el usuario a traves de la terminal para crear una variable
read nombre
# con ayuda de echo y del signo $ puedo llamar a la variable que anteriormente creé con el read
echo "hola mucho gusto $nombre , soy una terminal de Bash"
# con ayuda del echo me ayudo para darle un tono de mision importante, para adentrarse mas en el papel de la guerra
echo "El mensaje que estas a punto de enviar es muy importante para el fin de la guerra,"
echo "asi que necesito que seas muy preciso con el mensaje que desees codificar."
# en este echo vuelvo a escribir una instruccion para que el usuario pueda interactuar con la terminal
echo "En este punto ingresa el mensaje que deseas codificar para tus aliados: "
# me apoyo del read para poder crear la variable texto, que va a ser en este caso el mensaje que el usuario quiera escribir, en general
# es decir la terminal estara a la espera de que el usuario digite el mensaje para poder codificarlo
# con el comando read, creo en este caso la varialble texto, que vendria siendo el mismo mesaje
read texto
# le presento al usuario el mensaje que me pide que le transcriba
echo "El mensaje redactado fue el siguiente: "
#con ayuda del echo y del $ presento al usuario su mensaje
echo "$texto"
# me ayudo del echo para que la terminal se vea un poco mas interactiva con el usuario
echo "Tu mensaje se ha recibido satisfactoriamente, ahora sera redirigido a un archivo de texto me20202107044.txt"
# con touch me apoyo para crear el archivo me20202107044.txt, el cual sera eliminado cada ves que se ejecute el script
touch me20202107044.txt
# ahora quiero pasar ese texto a un archivo de texto, para eso tomo ayuda del signo >> para que esta informacion se consigne en el archivo txt
echo "$texto" >> me20202107044.txt
# igual mente me apoyo de signos y demas para que se vea como cierto estilo de titulo en la terminal, un poco mas atractico para el usuario
echo "Tu mensaje ha sido guardado en me20202107044.txt"
echo "Empezaremos la codificacion de tu texto ..."
echo "----------------------------------------------"
echo "--------------codificando texto ....----------"
echo "----------------------------------------------"
echo "."
echo "."
echo "."
# en este punto se le va reportando al usuario el estado de la codificacion
echo "El mensaje ha sido codificado con exito"
# el comando xxd en su forma original me ayuda a convertir la variable texto que definimos al sistema hexadecimal 
# a su vez le digo que por favor me envie los datos de esa conversion a archivo txt
echo "$texto" | xxd >> me20202107044.txt
# pensando en el usuario, le notifico que el mensaje va a aparecer sobre la terminal
echo "Mostrando codificacion sobre la terminal en base hexadecimal"
# con ayuda del comando cat le ayudo al usuario para mostrarle el mensaje original y el codificado sobre la terminal
cat me20202107044.txt
# ahora el comando xxd en su forma natural convierte los archivos a hexadecimal y viceversa, y el -b le especifica que los quiero
#convertir a binario, sumado a esto tambien le pido que por favor me envie esa conversion al archivo txt que habia creado
echo "$texto" | xxd -b >> me20202107044.txt
#le notifico al usuario que nuevamente aparecera el mensaje original y el codificado en las dos bases que hemos vonvertido
# hexadeciamal y binario
echo "Mostrando codificacion sobre la terminal en base hexadecimal y binaria"
#en este punto el cat me ayuda a mostrarle al usuario sobre la terminal ele mensaje codificado en binario
cat me20202107044.txt
#echo "obase=2; ibase=16; me20202107044.txt" | bc -->> esto era algo que estaba intentando pero no supe que mas hacer profe :(
