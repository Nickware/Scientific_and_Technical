
#averiguar tildes en un archivo bash (Configuración)
# actividades 25 de abril 
#nombre.sh 
#archivos sh incluyen rutinas - automatizacion de tareas 
#acciones a ejecutar 
#fase de un ejecutable 
#Warning 
#borrae archivos 
#sustituir archivos archivo.txt archivo.sh
#sustituir archivos 
# guardar sin preguntar 
#no guarda no pregunta 

cd /bin
ls *.exe
ls -la *.exe

