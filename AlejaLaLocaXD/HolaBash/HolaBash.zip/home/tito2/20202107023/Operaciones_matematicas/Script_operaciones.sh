#Taller operaciones matematicas 
# Author: Alejandra Moreno. 
# Versión 1.0.0

echo -e \ "Ingrese un numero por favor"
read numero
echo -e "El numero ingresado es $numero"
echo " Su correspondiente valor en el sistema  binario es: "
echo "obase=2; ibase=10; $numero" | bc  >> Numeros.txt 
echo 
#echo "Sus numeros son `bash Script_operaciones.sh`" >> Los_numeros.txt



