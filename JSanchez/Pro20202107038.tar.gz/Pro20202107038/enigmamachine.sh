echo hola juan encontramos esto para tí:
echo Carta que los nazis cifraron:
cat cartaCifrarNacisEntrada.txt
echo LUEGO ESTA CARTA SE CIFRÓ
echo
echo Carta de los nacis cifrada en Binario:
xxd -b  cartaCifrarNacisEntrada.txt cartaCifradaNacisb.txt
cat cartaCifradaNacisb.txt
echo
echo Carta de los nazis cifrada en Hexadecimal
xxd cartaCifrarNacisEntrada.txt cartaCifradaNacish.txt
cat cartaCifradaNacish.txt
echo
echo Hemos encontrado la carta cifrada de los Nazis en una en un txt en binario y otra en un txt hexadecimal como se mostró anteriormente
echo  -- 1 si Deseas decifrar la carta hexadecimal
echo  -- 2 si Deseas convertir la carta binaria a sistema octal
echo
read item1
if [  = 1 ]; then
xxd -r -p cartaCifradaNacish.txt cartaDecifradaNacis.txt
echo ¡DECIFRADO CON EXITO!
echo Ya has decifrado el archivo txt cartaCifradaNacis puedes encontrar el mensaje en cartaDecifradaNacis.txt
cat cartaDecifradaNacis.txt
else 
hexdump -b cartaCifradaNacisb.txt >> cartaCifradaNacisOctal.txt
cat cartaCifradaNacisOctal.txt
echo Ya has converitodo el archivo txt cartaCifradaNacis de Binario a Octal puedes encontrar el mensaje en cartaCifradaNacisOctal.txt
fi
echo Gracias por usar Enigma Machine
