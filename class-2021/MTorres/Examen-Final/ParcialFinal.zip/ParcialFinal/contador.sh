#!/usr/bin/bash.exe
#Title: Contador
#Authors: Julián Aros, Marcos Torres , Norman Romero
#Date: 12-10-21
#Version: 1.0.


echo "Bienvenido"

echo -n "Ingrese un valor de n : "
read n
max=$n
count=1
while [ true ]; do
   if [ "$count" = 500 ]; then
    echo $max
    exit
   fi
   echo -n "Ingrese un valor de n : "
   read n
   if [ "$n" -gt $max ]; then
    max=$n
   fi

   
   let count=count+1 
    
done 




