#Title: Primer Parcial-Cifrar .txt a hexal
#Author: Julián Aros
#Ultimo Digito Documento de Identificacion: 0 
#Ultimo Digito Codigo institucional: 0
#Date: 09-09-2021
#Version: 1.1
#!/usr/bin/bash.exe


echo "Conversion de texto a octal"
echo "Corroboración de que último dígito, tanto Documento como Código es impar" #Aquí los últimos dígitos son 0-0, para definir mi equipo me apoyo en el argumento de que al cero se le da el valor de par o impar según el autor
echo "No. Identificación: ---- --- 410"
echo "Código Institucional: 20202107050"
echo "Ubicando mi espacio de trabajo"
pwd
echo "Eliminando archivo de entrada.txt, archivo de salida.txt y ejecutable"
rm -rf entrada.txt
rm -rf salida.txt
rm -rf archivo.run


echo "Creando ejecutable.run"
touch archivo.run
echo "#Title: Primer Parcial-Cifrar .txt a hexal" >> archivo.run
echo "#Author: Julián Aros" >> archivo.run
echo "#Ultimo Digito Documento de Identificacion: 0" >> archivo.run
echo "#Ultimo Digito Codigo institucional: 0" >> archivo.run
echo "#Date: 09-09-2021" >> archivo.run
echo "#Version: 1.1" >> archivo.run
echo "#!/usr/bin/bash.exe" >> archivo.run

echo "echo "Ingresar mensaje para codificar a binario"" >> archivo.run
echo "echo -e "Ingrese su mensaje:"" >> archivo.run
echo "read mensaje" >> archivo.run
echo "echo "'$mensaje'" >> entrada.txt" >> archivo.run
echo "xxd entrada.txt > salida.txt" >> archivo.run 
echo "Ejecutando .run"
bash archivo.run

echo "Enlistar archivos"
ls -la
echo "Asigando permisos"
chmod 744 bi20202107050.sh
chmod 744 archivo.run
chmod 744 entrada.txt
chmod 744 salida.txt
echo "Comprobar permisos"
ls -la
echo "Comprimir"
gzip bi20202107050.sh
